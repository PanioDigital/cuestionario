Pure CSS Responsive animated info card, usada en la pagina de preguntas y respuestas.
https://codepen.io/BlogFire/pen/mdXNMVX

el boton con el enlace usa
https://prismic.io/blog/css-button-animations
    1.Glitch effect
    6. Magnetic field